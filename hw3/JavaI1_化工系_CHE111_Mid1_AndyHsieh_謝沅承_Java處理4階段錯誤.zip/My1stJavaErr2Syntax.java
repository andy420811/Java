class _2stMyJava {
    public static void main(String[] args) {
        int a = 0, b = 1         //the privious b=1 do not have a ';'
        int c; c = a + b;
        System.out.println("Hello! My "+ c +" st Baby comes into Being");

    }
}
