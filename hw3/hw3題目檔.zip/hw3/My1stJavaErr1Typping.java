class 1stMyJava{                            //error in first picture parameter's first letter cannot be number(範例)
    public static void main(String[]args){
        int a=0,b=1;
        int c;
        c=a+b;
        System.out.println("Hello! My "+c+" st Baby Come into Being");
        
    }
}