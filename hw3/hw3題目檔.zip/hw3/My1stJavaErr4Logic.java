class _1stMyJava {
    public static void main(String[] args) {
        int a=0,b=1; int c; c=b/a;   //(Error原因)
        System.out.println("Hello! My "+ c +" st Baby comes into Being");
    }
}
