class _2stMyJava {
    public static void main(String[] args) {
        int a = 0, b = 1         //(Error原因)
        int c; c = a + b;
        System.out.println("Hello! My "+ c +" st Baby comes into Being");

    }
}
