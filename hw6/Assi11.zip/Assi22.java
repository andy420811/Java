public class Assi22 {
    public static void main(String[] args) {
        float  a = 1; 
        float b,c;
        a = a-- - a-- - (b = -(-a/2)) - a - a-- - (c = (a--)/5) + ++a;
        System.out.println("a=" + a + "\t-(-a/2)=" + b + "\t(a--)/5=" + c);
        a = 1;
        a = ++a - (b = --a/2) + ++a + a - --a/(1- --a);
        System.out.println("a=" + a + "\t--a/2=" + b);
    }
}
